
/*
 * Welcome to Synerduino.
 * 
 * Synerduino is base off the multiwii Protocol updated and develop to suite the synerduino boards
 * with several updates and alteration from the old multiwii systems
 * 
 * http://www.synerflight.com
 * 
 *
 * If you see this message, chances are you are using the Arduino IDE. That is ok.
 * To get the MultiWii program configured for your copter, you must switch to the tab named 'config.h'.
 * Maybe that tab is not visible in the list at the top, then you must use the drop down list at the right
 * to access that tab. In that tab you must enable your baord or sensors and optionally various features.
 * For more info go to http://www.multiwii.com/wiki/index.php?title=Main_Page
 *
 * Have fun, and do not forget MultiWii is made possible and brought to you under the GPL License.
 *2020// Support for MMC5883 BMP280 QMC5883 sensors 
 *2022// Receive buffer in GPS.cpp  change to uint8_t bytes[128];
 *2024// GPS.cpp > NMEA in GPS.cpp  update on M8-M10 Protocol uncomment to support M8-M10 NMEA GPS
 *2024// GPS.cpp > ANGLE_MODE to support Home Reset Mode by uncommenting
 *2025// Support for QMC5883P > Mag update
 *2026// Support for GPS Ublox 9 and 10
 *2026// Sensors added BMI160  LSM6DSOX  ICM20689  BMP388 BMP390
 */
